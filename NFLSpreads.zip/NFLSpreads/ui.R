library(shiny)
library(shinydashboard)

dashboardPage(
  dashboardHeader(title = "NFL Gambling Data"
                  #, disable = TRUE
                  ),
  dashboardSidebar(
    sidebarMenu(
      menuItem("Background", tabName = "background"
               #, icon = icon()
               ),
      menuItem("Spreads", tabName = "spreads"
               #, icon = icon()
               ),
      menuItem("Over/Under",tabName = "overunder"
               #, icon = icon()
               )
  )),
  dashboardBody(
    tabItems(
      tabItem(tabName="background",
              img(src='https://imagesvc.timeincapp.com/v3/fan/image?url=https://fansided.com/wp-content/uploads/getty-images/2018/02/908549714-nfc-championship-minnesota-vikings-v-philadelphia-eagles.jpg.jpg&',
                  width='70%',height='70%')
              ),
      tabItem(tabName = "spreads", # each row should represent a graph (in the box), and the tabBox next to it let's you diddle the parameters
              fluidRow( # Distribution of Error
                h3(' Examining the distribution of error'),
                h5(' Error of 0 means the spread was exactly right. A positive error means the favorite beat the spread, while negative means the underdog beat the spread'),
                box(
                  plotOutput('DistributionOfError')
                ),
                tabBox(
                  title = tagList(shiny::icon("gear"), "Modify Chart"),
                  tabPanel("Bins",
                           sliderInput('BinsDistSpreads',min = 5,max = 50,value = 30,step = 5,label = 'Bins')
                           ),
                  tabPanel("By Season",
                           sliderInput('SeasonsDistSpreads',min=1979,max=2017,value=c(1979,2017),step=1,label='Seasons')
                          ),
                  tabPanel("By Team",
                           "Team:"
                           #, checklist('TeamDistSpreads'))
                  #find correct name for  dualSlider and checklist functions
                  
              ))),
              fluidRow( # Accuracy by Season
                h3('Other descriptive text about this second row'),
                box(),
                tabBox()
              ),
              fluidRow( # Accuracy by Week of Season
                box(),
                tabBox()
              ),
      tabItem(tabName = "overunder"
              
              )
    )
  )
)
)
