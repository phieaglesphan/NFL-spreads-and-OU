shinyServer(function(input, output) {
   
  output$spreadsDistribution <- renderPlot({
    ggplot(nfl  %>% filter(schedule_season>=input$SeasonsDistSpreads[1] & schedule_season<=input$SeasonsDistSpreads[2])
           ,aes(Error)) + geom_histogram(bins=input$BinsDistSpreads,col='black',fill='darkgreen')
  })
  
})
