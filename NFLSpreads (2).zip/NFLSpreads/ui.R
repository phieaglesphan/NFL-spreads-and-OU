shinyUI(dashboardPage(
  dashboardHeader(title = "NFL Gambling Data"
                  #, disable = TRUE
                  ),
  dashboardSidebar(
    sidebarMenu(id = 'sidebar',
      menuItem("Background", tabName = "background"
               #, iconid =  = icon()
               ),
      menuItem("Spreads", tabName = "spreads_dropdown",
               #, icon = icon()
               menuItem("Distribution of Error", tabName='spreadsHist'
                        #, icon = icon()
                        ),
               menuItem("Inaccuracy by Season", tabName = 'spreadsSeason'
                        #, icon = icon()
                        ),
               menuItem("Inaccuracy by Week", tabName = 'spreadsWeek'
                        #, icon = icon()
                        )
               ),
      menuItem("Over/Under",tabName = "overunder_dropdown",
               #, icon = icon()
               menuItem("Distribution of Error", tabName = 'ouHist'
                        #, icon = icon())
               )
  ))),
  dashboardBody(
    tabItems(
      tabItem(tabName="background",
              img(src='https://imagesvc.timeincapp.com/v3/fan/image?url=https://fansided.com/wp-content/uploads/getty-images/2018/02/908549714-nfc-championship-minnesota-vikings-v-philadelphia-eagles.jpg.jpg&',
                  width='95%',height='95%')
              ),
      tabItem(tabName = "spreadsHist", 
              fluidRow( # Distribution of Error
                h3(' Examining the distribution of error'),
                h5(' Error of 0 means the spread was exactly right. A positive error means the favorite beat the spread, while negative means the underdog beat the spread'),
                box(
                  plotOutput('DistributionOfError')
                )),
              fluidRow(
                box(
                  title = tagList(shiny::icon("gear"), "Modify Chart"), solidHeader = T,
                  #tabPanel("Bins",
                           sliderInput('BinsDistSpreads',min = 5,max = 50,value = 30,step = 5,label = 'Bins'),
                          # ),
                  #tabPanel("By Season",
                           sliderInput('SeasonsDistSpreads',min=1979,max=2017,value=c(1979,2017),step=1,label='Seasons',sep='')
                         # ),
                  #tabPanel("By Team",
                          # selectInput('TeamDistSpreads', label='Pick teams:', teams, selected=teams[1], multiple = T)
              ))),
      tabItem(tabName='spreadsSeason'), #Inaccuracy by Season Tab Page
              fluidRow( # Inaccuracy by Season Chart
                h3('Descriptive text explaing the chart below'),
                box()
              ),
              fluidRow( # Inaccuracy by Season chart adjustment box
                box()
              ),
      tabItem(tabName = 'spreadsWeek'), #Inaccuracy by Week Tab Page
              fluidRow( # Inaccuracy by Week Chart)
                h3("Inaccuracy by week chunk it out ya dingus"),
                box()
              ),
              fluidRow( # Inaccuracy by Week chart adjustment box
                box()
              ),
      tabItem(tabName = "ouHist",
              fluidRow( )
              
    )
  )
)
))
