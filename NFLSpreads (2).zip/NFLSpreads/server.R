shinyServer(function(input, output,session) {

  #updateSelectizeInput(session, "TeamDistSpreads", choices = teams, server = TRUE)
  
############################################################## FILTERING TEAMS ##################################################################
  
  # filtered_data = nfl
  # data_filter = reactive({
  #   if(length(input$teams)) {
  #     filtered_data = filtered_data %>% filter(team_home==input$TeamDistSpreads | team_away==input$TeamDistSpreads)
  #   }
  # })
  # 
  # observe({
  #   if ("Select All" %in% input$TeamDistSpreads) {
  #     # choose all the choices _except_ "Select All"
  #     selected_choices <- setdiff(teams, "Select All")
  #     updateSelectInput(session,"TeamDistSpreads", selected = selected_choices)
  # 
  #   }
  # })
  
  
############################################################# OUTPUT ############################################################################
  
  
  
  output$DistributionOfError <- renderPlot({
    ggplot(nfl  %>% filter(schedule_season>=input$SeasonsDistSpreads[1] & schedule_season<=input$SeasonsDistSpreads[2])
              #  %>% filter(team_home==input$TeamDistSpreads|team_away==input$TeamDistSpreads)
           ,aes(Error)) + geom_histogram(bins=input$BinsDistSpreads,col='black',fill='darkgreen')
  })
 
})
